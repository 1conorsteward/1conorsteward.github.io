package com.example.appointmentnow_steward;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import android.Manifest;


public class EventDetailActivity extends AppCompatActivity {

    private TextView patientNameTextView;
    private TextView doctorNameTextView;
    private TextView appointmentDateTextView;
    private TextView statusTextView;
    private TextView notesTextView;
    private TextView locationTextView;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_detail);

        // Initialize views
        patientNameTextView = findViewById(R.id.patient_name);
        doctorNameTextView = findViewById(R.id.doctor_name);
        appointmentDateTextView = findViewById(R.id.appointment_date);
        statusTextView = findViewById(R.id.status);
        notesTextView = findViewById(R.id.notes);
        locationTextView = findViewById(R.id.location);

        // Initialize close button and set click listener
        ImageButton closeButton = findViewById(R.id.close_button);
        closeButton.setOnClickListener(v -> finish());  // Close the activity when the close button is clicked

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Get event ID from intent
        Intent intent = getIntent();
        long eventId = intent.getLongExtra("event_id", -1);

        // Check if eventId is valid
        if (eventId != -1) {
            // Load event details from the database
            loadEventDetails(eventId);
        } else {
            // Show an error message if event ID is invalid
            Toast.makeText(this, "Error Finding Event", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity
        }

        // Check and request for WRITE_EXTERNAL_STORAGE permission
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
            requestPermissions(permissions, 1001);  // Requesting the permission
        }

        // Initialize Export Button and set click listener
        Button exportButton = findViewById(R.id.export_button);
        exportButton.setOnClickListener(v -> exportVisitAsPDF());
    }

    private void exportVisitAsPDF() {
        // Create a new PdfDocument
        PdfDocument pdfDocument = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);

        // Initialize a canvas to draw on the PDF
        Canvas canvas = page.getCanvas();
        Paint paint = new Paint();
        paint.setTextSize(16);

        // Get the text from the TextViews
        String title = "Visit Details";
        String patientName = "Patient Name: " + patientNameTextView.getText().toString();
        String doctorName = "Doctor Name: " + doctorNameTextView.getText().toString();
        String appointmentDate = "Appointment Date: " + appointmentDateTextView.getText().toString();
        String status = "Status: " + statusTextView.getText().toString();
        String notes = "Notes: " + notesTextView.getText().toString();
        String location = "Location: " + locationTextView.getText().toString();

        // Draw text onto the PDF
        canvas.drawText(title, 50, 50, paint);
        canvas.drawText(patientName, 50, 100, paint);
        canvas.drawText(doctorName, 50, 150, paint);
        canvas.drawText(appointmentDate, 50, 200, paint);
        canvas.drawText(status, 50, 250, paint);
        canvas.drawText(notes, 50, 300, paint);
        canvas.drawText(location, 50, 350, paint);

        // Finish the page
        pdfDocument.finishPage(page);

        // Determine the file path
        File pdfFile;
        // Save to the app's specific directory on Android 10 and above
        pdfFile = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "visit_details.pdf");

        try {
            // Save the PDF document
            pdfDocument.writeTo(Files.newOutputStream(pdfFile.toPath()));
            Toast.makeText(this, "PDF exported successfully!", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            // Use Log.e instead of printStackTrace for robust logging
            Log.e("EventDetailActivity", "Error exporting PDF", e);
            Toast.makeText(this, "Error exporting PDF", Toast.LENGTH_SHORT).show();
        }

        // Close the document
        pdfDocument.close();
    }


    private void loadEventDetails(long eventId) {
        Cursor cursor = databaseHelper.getEventById(eventId);
        if (cursor != null && cursor.moveToFirst()) {
            patientNameTextView.setText(cursor.getString(cursor.getColumnIndexOrThrow("patient_name")));
            doctorNameTextView.setText(cursor.getString(cursor.getColumnIndexOrThrow("doctor_name")));
            appointmentDateTextView.setText(cursor.getString(cursor.getColumnIndexOrThrow("appointment_date")));
            statusTextView.setText(cursor.getString(cursor.getColumnIndexOrThrow("status")));
            notesTextView.setText(cursor.getString(cursor.getColumnIndexOrThrow("notes")));
            locationTextView.setText(cursor.getString(cursor.getColumnIndexOrThrow("location")));
            cursor.close();
        } else {
            Toast.makeText(this, "Event Not Found", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity if event is not found
        }
    }
}
