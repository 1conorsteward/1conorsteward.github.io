package com.example.appointmentnow_steward;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity handles the user interface for logging in and creating a new account.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText username; // Input field for the username
    private EditText password; // Input field for the password

    private DatabaseHelper dbHelper; // Database helper for user validation

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize views by finding them from the layout resource
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login_button); // Button to initiate the login process
        Button createAccountButton = findViewById(R.id.create_account_button); // Button to open the create account activity

        // Initialize the database helper
        dbHelper = new DatabaseHelper(this);

        // Set the input type for the password field to mask the text input with ***
        password.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        // Set listeners for buttons
        loginButton.setOnClickListener(v -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();
            if (validateLogin(user, pass)) {
                // If login is successful, save user_id in SharedPreferences
                long userId = getUserId(user);  // Fetch user ID based on the email or username

                if (userId != -1) {
                    // Save the user_id in SharedPreferences
                    SharedPreferences sharedPref = getSharedPreferences("AppPreferences", MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putLong("user_id", userId); // Store the user_id
                    editor.apply();

                    // Navigate to EventDisplayActivity
                    Intent intent = new Intent(LoginActivity.this, EventDisplayActivity.class);
                    startActivity(intent);
                    finish(); // Close the LoginActivity
                } else {
                    // Show error if user ID is not found
                    Toast.makeText(LoginActivity.this, "Error retrieving user ID.", Toast.LENGTH_SHORT).show();
                }
            } else {
                // Show error message
                Toast.makeText(LoginActivity.this, getString(R.string.password_fail), Toast.LENGTH_SHORT).show();
            }
        });

        createAccountButton.setOnClickListener(v -> {
            // Start RegisterActivity to create a new account
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }

    // Method to validate user login
    private boolean validateLogin(String email, String password) {
        Cursor cursor = dbHelper.getReadableDatabase().rawQuery(
                "SELECT * FROM " + dbHelper.getTableUsers() + " WHERE " +
                        dbHelper.getColumnUserEmail() + "=? AND " +
                        dbHelper.getColumnUserPassword() + "=?",
                new String[]{email, password});

        if (cursor != null && cursor.moveToFirst()) {
            // User found with matching credentials
            cursor.close();
            return true;
        }

        if (cursor != null) {
            cursor.close();
        }
        // No matching user found
        return false;
    }

    // Method to get user ID by email or username
    private long getUserId(String email) {
        Cursor cursor = dbHelper.getReadableDatabase().rawQuery(
                "SELECT " + dbHelper.getColumnUserId() + " FROM " + dbHelper.getTableUsers() +
                        " WHERE " + dbHelper.getColumnUserEmail() + " = ?",
                new String[]{email});

        if (cursor != null && cursor.moveToFirst()) {
            // Retrieve the user ID from the database
            long userId = cursor.getLong(cursor.getColumnIndexOrThrow(dbHelper.getColumnUserId()));
            cursor.close();
            return userId;
        }

        if (cursor != null) {
            cursor.close();
        }

        return -1;  // Return -1 if the user ID was not found
    }
}
