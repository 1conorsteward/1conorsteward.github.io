package com.example.appointmentnow_steward;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "AppointmentNow.db";
    private static final int DATABASE_VERSION = 2;

    // Table names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_EVENTS = "events";

    // Columns for the users table
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_EMAIL = "email";
    private static final String COLUMN_USER_PASSWORD = "password";
    private static final String COLUMN_USER_SMS_PERMISSION = "sms_permission";

    // Columns for the events table
    private static final String COLUMN_EVENT_ID = "event_id";
    private static final String COLUMN_PATIENT_NAME = "patient_name";
    private static final String COLUMN_DOCTOR_NAME = "doctor_name";
    private static final String COLUMN_APPOINTMENT_DATE = "appointment_date";
    private static final String COLUMN_STATUS = "status";
    private static final String COLUMN_NOTES = "notes";
    private static final String COLUMN_LOCATION = "location";

    // SQL to create users table
    private static final String CREATE_TABLE_USERS = "CREATE TABLE " + TABLE_USERS + " ("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_USER_EMAIL + " TEXT, "
            + COLUMN_USER_PASSWORD + " TEXT, "
            + COLUMN_USER_SMS_PERMISSION + " INTEGER)";

    // SQL to create events table
    private static final String CREATE_TABLE_EVENTS = "CREATE TABLE " + TABLE_EVENTS + " ("
            + COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "  // Event ID auto-incremented
            + COLUMN_PATIENT_NAME + " TEXT, "
            + COLUMN_DOCTOR_NAME + " TEXT, "
            + COLUMN_APPOINTMENT_DATE + " TEXT, "
            + COLUMN_STATUS + " TEXT, "
            + COLUMN_NOTES + " TEXT, "
            + COLUMN_LOCATION + " TEXT, "
            + COLUMN_USER_ID + " INTEGER, "  // Foreign key from users table
            + "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + ") "
            + "ON DELETE CASCADE ON UPDATE CASCADE"  // Optional: cascade on delete and update
            + ");";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            db.execSQL("PRAGMA foreign_keys=ON;");
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
        db.execSQL(CREATE_TABLE_EVENTS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //Check the DB version and update the table for the new features
        if ( oldVersion < 2) {
            db.execSQL("ALTER TABLE " + TABLE_EVENTS + " ADD COLUMN " + COLUMN_USER_ID + " INTEGER;");
        }

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EVENTS);
        onCreate(db);
    }

    // Getter for TABLE_USERS
    public String getTableUsers() {
        return TABLE_USERS;
    }

    // Getter for COLUMN_USER_EMAIL
    public String getColumnUserEmail() {
        return COLUMN_USER_EMAIL;
    }

    // Getter for COLUMN_USER_PASSWORD
    public String getColumnUserPassword() {
        return COLUMN_USER_PASSWORD;
    }

    // Getter for COLUMN_USER_ID
    public String getColumnUserId() { return COLUMN_USER_ID; }

    // Method to get events by user ID
    public Cursor getEventsByUserId(long userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_EVENTS + " WHERE " + COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});
    }

    //Method to get status "completed" events
    public Cursor getCompletedEvents(long userId, String searchTerm) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EVENTS + " WHERE "
                + COLUMN_USER_ID + " = ? AND "
                + COLUMN_STATUS + " = 'Completed' AND "
                + COLUMN_PATIENT_NAME + " LIKE ?";
        return db.rawQuery(query, new String[]{String.valueOf(userId), "%" + searchTerm + "%"});
    }

    // Method to add a new user
    public long addUser(String email, String password, int smsPermission) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_EMAIL, email);
        values.put(COLUMN_USER_PASSWORD, password);
        values.put(COLUMN_USER_SMS_PERMISSION, smsPermission);
        return db.insert(TABLE_USERS, null, values);
    }

    // Method to add a new event
    public long addEvent(String patientName, String doctorName, String appointmentDate,
                         String status, String notes, String location, long userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PATIENT_NAME, patientName);
        values.put(COLUMN_DOCTOR_NAME, doctorName);
        values.put(COLUMN_APPOINTMENT_DATE, appointmentDate);
        values.put(COLUMN_STATUS, status);
        values.put(COLUMN_NOTES, notes);
        values.put(COLUMN_LOCATION, location);
        values.put(COLUMN_USER_ID, userId);

        long id = db.insert(TABLE_EVENTS, null, values);
        db.close();  // Close the database connection
        return id;
    }


    // Method to get a specific event by ID
    public Cursor getEventById(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_EVENTS + " WHERE " + COLUMN_EVENT_ID + "=?", new String[]{String.valueOf(id)});
    }


    // Method to update an event in the database
    public boolean updateEvent(long id, String patientName, String doctorName, String appointmentDate, String status, String notes, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PATIENT_NAME, patientName);
        values.put(COLUMN_DOCTOR_NAME, doctorName);
        values.put(COLUMN_APPOINTMENT_DATE, appointmentDate);
        values.put(COLUMN_STATUS, status);
        values.put(COLUMN_NOTES, notes);
        values.put(COLUMN_LOCATION, location);

        int rows = db.update(TABLE_EVENTS, values, COLUMN_EVENT_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    // Method to delete an event from the database
    public boolean deleteEvent(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_EVENTS, COLUMN_EVENT_ID + " = ?", new String[]{String.valueOf(id)});
        return rows > 0;
    }
}
