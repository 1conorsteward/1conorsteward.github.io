package com.example.appointmentnow_steward;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class EventDisplayActivity extends AppCompatActivity {

    private ArrayList<Event> eventList;
    private EventAdapter eventAdapter;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_display);

        // Initialize UI components
        GridView eventGrid = findViewById(R.id.event_grid);
        Button addEventButton = findViewById(R.id.add_event_button);
        ImageButton smsPermissionButton = findViewById(R.id.sms_permission_button);
        ImageButton logoutButton = findViewById(R.id.action_logout); // Logout button

        // Initialize database helper
        databaseHelper = new DatabaseHelper(this);

        // Load events from the database
        loadEvents();

        // Set up the event adapter for the GridView
        eventAdapter = new EventAdapter(this, eventList);
        eventGrid.setAdapter(eventAdapter);

        // Handle event item click
        eventGrid.setOnItemClickListener((parent, view, position, id) -> {
            Event clickedEvent = eventList.get(position);
            openEventDetailActivity(clickedEvent.getId());
        });

        // History button click listener
        ImageButton historyButton = findViewById(R.id.history_button);
        historyButton.setOnClickListener(v -> {
            Intent intent = new Intent(EventDisplayActivity.this, HistoryActivity.class);
            startActivity(intent);
        });

        // Add event button click listener
        addEventButton.setOnClickListener(v -> openAddOrEditEventDialog(null, -1));

        // SMS permission button click listener
        smsPermissionButton.setOnClickListener(v -> openSMSPermissionActivity());

        // Logout button click listener
        logoutButton.setOnClickListener(v -> {
            // Clear user session or token
            SharedPreferences sharedPref = getSharedPreferences("AppPreferences", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            editor.clear();  // Clear all saved preferences (log out user)
            editor.apply();

            //Clear the event list
            eventList.clear();

            // Go back to the login page
            Intent intent = new Intent(EventDisplayActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();  // Close the EventDisplayActivity
        });
    }

    private void loadEvents() {
        // Initialize eventList if it's not already done
        if (eventList == null) {
            eventList = new ArrayList<>();
        }

        eventList.clear();  // Clear the list to avoid duplicates

        // Retrieve the logged-in user ID from SharedPreferences
        SharedPreferences sharedPref = getSharedPreferences("AppPreferences", MODE_PRIVATE);
        long userId = sharedPref.getLong("user_id", -1);  // Default to -1 if not found

        if (userId != -1) {
            // Load events for this user
            try (Cursor cursor = databaseHelper.getEventsByUserId(userId)) {
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        long id = cursor.getLong(cursor.getColumnIndexOrThrow("event_id"));
                        String patientName = cursor.getString(cursor.getColumnIndexOrThrow("patient_name"));
                        String doctorName = cursor.getString(cursor.getColumnIndexOrThrow("doctor_name"));
                        String appointmentDate = cursor.getString(cursor.getColumnIndexOrThrow("appointment_date"));
                        String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
                        String notes = cursor.getString(cursor.getColumnIndexOrThrow("notes"));
                        String location = cursor.getString(cursor.getColumnIndexOrThrow("location"));

                        // Add event to the list
                        eventList.add(new Event(id, patientName, doctorName, appointmentDate, status, notes, location));
                    }
                }
            } catch (Exception e) {
                Log.e("EventDisplayActivity", "Error loading events: ", e);
            }
        } else {
            // Handle case where user ID is not found
            Toast.makeText(this, "Error loading events. Please log in again.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
        }
    }

    private void openEventDetailActivity(long eventId) {
        Intent intent = new Intent(this, EventDetailActivity.class);
        intent.putExtra("event_id", eventId);
        startActivity(intent);
    }

    public void showDeleteConfirmationDialog(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage("Are you sure you want to delete this event?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    // Delete the event from the database
                    long eventId = eventList.get(position).getId();
                    boolean deleted = databaseHelper.deleteEvent(eventId);

                    // Remove the event from the list and refresh the adapter
                    if (deleted) {
                        eventList.remove(position);
                        eventAdapter.notifyDataSetChanged();
                        Toast.makeText(this, "Event deleted successfully!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Error deleting event.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    public void openAddOrEditEventDialog(Event event, int position) {
        AddEventDialogFragment dialog;
        if (event == null) {
            dialog = new AddEventDialogFragment();
        } else {
            dialog = AddEventDialogFragment.newInstance(event);  // For editing
        }

        dialog.setOnSaveListener(newEvent -> {
            SharedPreferences sharedPref = getSharedPreferences("AppPreferences", MODE_PRIVATE);
            long userId = sharedPref.getLong("user_id", -1);

            if (userId != -1) {
                if (event == null) {  // Adding a new event
                    // Save the event to the database with the user ID
                    long id = databaseHelper.addEvent(
                            newEvent.getPatientName(),
                            newEvent.getDoctorName(),
                            newEvent.getAppointmentDate(),
                            newEvent.getStatus(),
                            newEvent.getNotes(),
                            newEvent.getLocation(),
                            userId  // Pass the user ID to associate the event with the user
                    );

                    // Add the event to the list and refresh the adapter
                    if (id != -1) {
                        newEvent.setId(id);
                        eventList.add(newEvent);
                        eventAdapter.notifyDataSetChanged();
                        Toast.makeText(this, "Event added successfully!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Error adding event.", Toast.LENGTH_SHORT).show();
                    }
                } else {  // Editing an existing event
                    Log.d("EventUpdate", "Updating event with ID: " + event.getId());

                    // Update the event in the database
                    boolean updated = databaseHelper.updateEvent(
                            event.getId(),
                            newEvent.getPatientName(),
                            newEvent.getDoctorName(),
                            newEvent.getAppointmentDate(),
                            newEvent.getStatus(),
                            newEvent.getNotes(),
                            newEvent.getLocation()
                    );

                    // Update the event in the list and refresh the adapter
                    if (updated) {
                        eventList.set(position, newEvent);
                        eventAdapter.notifyDataSetChanged();
                        Toast.makeText(this, "Event updated successfully!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Error updating event.", Toast.LENGTH_SHORT).show();
                    }
                }
            } else {
                Toast.makeText(this, "User ID not found. Please log in again.", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show(getSupportFragmentManager(), "AddOrEditEventDialog");
    }

    private void openSMSPermissionActivity() {
        Intent intent = new Intent(this, SMSPermissionActivity.class);
        startActivity(intent);
    }
}
