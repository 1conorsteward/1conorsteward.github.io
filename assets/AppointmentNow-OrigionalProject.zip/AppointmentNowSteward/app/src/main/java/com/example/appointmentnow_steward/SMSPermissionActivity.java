package com.example.appointmentnow_steward;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.widget.SwitchCompat;

// This activity handles SMS permission management, including requesting and revoking permissions.
public class SMSPermissionActivity extends AppCompatActivity {

    // Request code for SMS permission
    private static final int SMS_PERMISSION_CODE = 1001;

    // UI components
    private TextView smsPermissionInfo;  // TextView to display the current permission status
    private SwitchCompat permissionToggle;  // Switch to toggle SMS permission

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_permission);

        // Initialize views from the layout
        smsPermissionInfo = findViewById(R.id.sms_permission_info);
        permissionToggle = findViewById(R.id.permission_toggle);
        ImageButton closeButton = findViewById(R.id.close_button);

        // Set click listener for the close button to finish the activity
        closeButton.setOnClickListener(v -> finish());

        // Set up the toggle switch based on the current SMS permission state
        checkSmsPermission();

        // Set a listener for the toggle switch to handle permission changes
        permissionToggle.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                checkAndRequestSMSPermission();  // Request permission if toggled on
            } else {
                handlePermissionRevocation();  // Handle revocation attempt if toggled off
            }
        });
    }

    // Method to check and request SMS permission
    private void checkAndRequestSMSPermission() {
        // Check if SMS permission is not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Request the SEND_SMS permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            // If permission is already granted, update the UI
            smsPermissionInfo.setText(R.string.permission_granted);
            permissionToggle.setChecked(true);
        }
    }

    // Method to check the current SMS permission state and update the UI accordingly
    private void checkSmsPermission() {
        // Check if SMS permission is not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            // Update UI to indicate permission is denied
            permissionToggle.setChecked(false);
            smsPermissionInfo.setText(R.string.permission_denied);
        } else {
            // Update UI to indicate permission is granted
            permissionToggle.setChecked(true);
            smsPermissionInfo.setText(R.string.permission_granted);
        }
    }

    // Method to handle the case where the user attempts to revoke the permission via the toggle switch
    private void handlePermissionRevocation() {
        // Show a toast message indicating that SMS permission needs to be revoked manually
        Toast.makeText(this, "SMS Permission needs to be revoked from the settings manually.", Toast.LENGTH_LONG).show();
        // Set the toggle switch back to 'checked' state as revocation cannot be handled directly by the app
        permissionToggle.setChecked(true);
    }

    // Callback method to handle the result of a permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // Check if the result is for the SMS permission request
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // If permission is granted, update the UI
                smsPermissionInfo.setText(R.string.permission_granted);
                permissionToggle.setChecked(true);
            } else {
                // If permission is denied, update the UI
                smsPermissionInfo.setText(R.string.permission_denied);
                permissionToggle.setChecked(false);
            }
        }
    }
}
