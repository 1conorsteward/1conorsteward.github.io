package com.example.appointmentnow_steward;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText emailField;
    private EditText passwordField;
    private EditText reEnterPasswordField;
    private CheckBox smsNotificationsCheckbox;

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_create_account);

        // Initialize views
        emailField = findViewById(R.id.email);
        passwordField = findViewById(R.id.password);
        reEnterPasswordField = findViewById(R.id.re_enter_password);
        smsNotificationsCheckbox = findViewById(R.id.sms_notifications);
        Button registerButton = findViewById(R.id.register_button);

        // Initialize the database helper
        dbHelper = new DatabaseHelper(this);

        // Handle back button press
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Handle the back button event
                finish(); // Close the RegisterActivity
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);

        // Set click listener for the back button
        findViewById(R.id.back_button).setOnClickListener(v -> {
            finish(); // Close the RegisterActivity when the back button is pressed
        });

        // Set click listener for the register button
        registerButton.setOnClickListener(v -> {
            String email = emailField.getText().toString();
            String password = passwordField.getText().toString();
            String reEnterPassword = reEnterPasswordField.getText().toString();
            boolean smsPermission = smsNotificationsCheckbox.isChecked();

            if (email.isEmpty() || password.isEmpty() || reEnterPassword.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else if (!password.equals(reEnterPassword)) {
                Toast.makeText(RegisterActivity.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            } else {
                // Save the user in the database
                long userId = dbHelper.addUser(email, password, smsPermission ? 1 : 0);

                if (userId != -1) {
                    // Registration successful, log the user in
                    Intent intent = new Intent(RegisterActivity.this, EventDisplayActivity.class);
                    startActivity(intent);
                    finish(); // Close the RegisterActivity
                } else {
                    Toast.makeText(RegisterActivity.this, "Registration failed, try again", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
