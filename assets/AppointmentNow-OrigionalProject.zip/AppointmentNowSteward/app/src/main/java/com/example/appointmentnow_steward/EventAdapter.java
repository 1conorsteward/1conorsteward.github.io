package com.example.appointmentnow_steward;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import java.util.ArrayList;

public class EventAdapter extends BaseAdapter {
    private final Context context;
    private final ArrayList<Event> events;

    public EventAdapter(Context context, ArrayList<Event> events) {
        this.context = context;
        this.events = events;
    }

    @Override
    public int getCount() {
        return events.size();
    }

    @Override
    public Object getItem(int position) {
        return events.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.event_item, parent, false);
        }

        Event event = (Event) getItem(position);

        // Initialize UI components for the list item
        TextView eventTitle = convertView.findViewById(R.id.event_title);
        TextView eventSubtitle = convertView.findViewById(R.id.event_subtitle);
        TextView eventStatus = convertView.findViewById(R.id.event_status);  // New TextView for status
        ImageButton editButton = convertView.findViewById(R.id.edit_event_button);
        ImageButton deleteButton = convertView.findViewById(R.id.delete_event_button);

        // Set data for the list item
        eventTitle.setText(event.getPatientName());  // Set patient name as title
        eventSubtitle.setText(event.getDoctorName());  // Set doctor name as subtitle
        eventStatus.setText(event.getStatus());  // Set event status

        // Set a click listener on the entire view to open EventDetailActivity
        convertView.setOnClickListener(v -> {
            Intent intent = new Intent(context, EventDetailActivity.class);
            intent.putExtra("event_id", event.getId());  // Pass the event ID to the detail activity
            context.startActivity(intent);
        });

// Edit event functionality for both EventDisplayActivity and HistoryActivity
        editButton.setOnClickListener(v -> {
            if (context instanceof EventDisplayActivity) {
                ((EventDisplayActivity) context).openAddOrEditEventDialog(event, position);
            } else if (context instanceof HistoryActivity) {
                ((HistoryActivity) context).openEditEventDialog(event, position);
            }
        });

// Delete event functionality for both EventDisplayActivity and HistoryActivity
        deleteButton.setOnClickListener(v -> {
            if (context instanceof EventDisplayActivity) {
                ((EventDisplayActivity) context).showDeleteConfirmationDialog(position);
            } else if (context instanceof HistoryActivity) {
                ((HistoryActivity) context).showDeleteConfirmationDialog(event.getId(), position);
            }
        });

        return convertView;
    }
}
