package com.example.appointmentnow_steward;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.util.Log;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;

public class AddEventDialogFragment extends DialogFragment {

    // Declare UI components
    private EditText patientName;
    private EditText doctorName;
    private EditText appointmentDate;
    private Spinner appointmentStatus;
    private EditText appointmentNotes;
    private EditText appointmentLocation;
    private Calendar calendar;

    private Event event;

    private DatabaseHelper databaseHelper;

    // Interface for callback when the save button is clicked
    public interface OnSaveListener {
        void onSave(Event event);
    }

    private OnSaveListener onSaveListener;

    public void setOnSaveListener(OnSaveListener onSaveListener) {
        this.onSaveListener = onSaveListener;
    }

    // newInstance Method
    public static AddEventDialogFragment newInstance(Event event) {
        AddEventDialogFragment fragment = new AddEventDialogFragment();
        Bundle args = new Bundle();
        args.putParcelable("event", event);  // Assuming Event implements Parcelable
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_add_event, container, false);

        // Initialize UI components
        patientName = view.findViewById(R.id.patient_name);
        doctorName = view.findViewById(R.id.doctor_name);
        appointmentDate = view.findViewById(R.id.appointment_date);
        appointmentStatus = view.findViewById(R.id.appointment_status);
        appointmentNotes = view.findViewById(R.id.appointment_notes);
        appointmentLocation = view.findViewById(R.id.appointment_location);
        Button saveEventButton = view.findViewById(R.id.save_event_button);
        ImageButton closeButton = view.findViewById(R.id.close_button);
        calendar = Calendar.getInstance();

        databaseHelper = new DatabaseHelper(getContext());

        // Set up close button listener
        closeButton.setOnClickListener(v -> dismiss());

        // Set up date picker for the appointment date EditText
        appointmentDate.setOnClickListener(v -> new DatePickerDialog(requireContext(), dateSetListener,
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)).show());

        // Check if this fragment was instantiated with an existing event
        if (getArguments() != null) {
                event = getArguments().getParcelable("event", Event.class);

            if (event != null) {
                // Pre-fill the fields with the event data
                patientName.setText(event.getPatientName());
                doctorName.setText(event.getDoctorName());
                appointmentDate.setText(event.getAppointmentDate());
                setSpinnerSelectionByValue(appointmentStatus, event.getStatus());
                appointmentNotes.setText(event.getNotes());
                appointmentLocation.setText(event.getLocation());

                // Update the calendar to the existing appointment date
                try {
                    String myFormat = "yyyy-MM-dd";
                    SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
                    calendar.setTime(Objects.requireNonNull(sdf.parse(event.getAppointmentDate())));
                } catch (Exception e) {
                    Log.e("AddEventDialogFragment", "Error parsing date: " + e.getMessage(), e);
                }
            }
        }

        // Save button click listener with input validation
        saveEventButton.setOnClickListener(v -> {
            if (validateInputs()) {
                if (getActivity() != null) {
                    SharedPreferences sharedPref = getActivity().getSharedPreferences("AppPreferences", Context.MODE_PRIVATE);
                    long userId = sharedPref.getLong("user_id", -1);

                    if (userId != -1) {
                        long eventId = databaseHelper.addEvent(
                                patientName.getText().toString(),
                                doctorName.getText().toString(),
                                appointmentDate.getText().toString(),
                                appointmentStatus.getSelectedItem().toString(),
                                appointmentNotes.getText().toString(),
                                appointmentLocation.getText().toString(),
                                userId  // Pass the user ID
                        );

                        if (eventId != -1) {
                            Toast.makeText(getContext(), "Event added successfully!", Toast.LENGTH_SHORT).show();
                            if (onSaveListener != null) {
                                onSaveListener.onSave(createEventFromInputs());
                            }
                            dismiss();  // Close the dialog after saving
                        } else {
                            Toast.makeText(getContext(), "Error adding event.", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getContext(), "User ID not found. Please log in again.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), "Error: Fragment not attached to Activity.", Toast.LENGTH_SHORT).show();
                }
            }
        });


        return view;
    }

    // Date picker dialog listener to update the EditText with the selected date
    private final DatePickerDialog.OnDateSetListener dateSetListener = (view, year, monthOfYear, dayOfMonth) -> {
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.MONTH, monthOfYear);
        calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        updateLabel();  // Update the EditText with the new date
    };

    // Update the appointmentDate EditText with the selected date in a specific format
    private void updateLabel() {
        String myFormat = "yyyy-MM-dd";  // Date format
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        appointmentDate.setText(sdf.format(calendar.getTime()));
    }

    // Validate inputs before saving
    private boolean validateInputs() {
        // Validate patient name
        if (patientName.getText().toString().trim().isEmpty()) {
            patientName.setError("Patient name is required");
            return false;
        }

        // Validate doctor name
        if (doctorName.getText().toString().trim().isEmpty()) {
            doctorName.setError("Doctor name is required");
            return false;
        }

        // Validate appointment date
        if (appointmentDate.getText().toString().trim().isEmpty()) {
            appointmentDate.setError("Appointment date is required");
            return false;
        }

        // Validate appointment date format (if manually entered)
        if (!isValidDate(appointmentDate.getText().toString())) {
            appointmentDate.setError("Invalid date format. Use yyyy-MM-dd.");
            return false;
        }

        // Validate status (Spinner selection)
        if (appointmentStatus.getSelectedItem() == null) {
            Toast.makeText(getContext(), "Please select an appointment status", Toast.LENGTH_SHORT).show();
            return false;
        }

        // Notes validation (optional field, can set a character limit)
        if (appointmentNotes.getText().toString().length() > 200) {
            appointmentNotes.setError("Notes cannot exceed 200 characters");
            return false;
        }

        // Location validation (optional)
        if (appointmentLocation.getText().toString().trim().isEmpty()) {
            appointmentLocation.setError("Location is required");
            return false;
        }

        return true; // If all validations pass
    }

    // Helper method to validate date format (if necessary)
    private boolean isValidDate(String date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        sdf.setLenient(false);
        try {
            sdf.parse(date);  // try to parse the date string
        } catch (ParseException e) {
            return false;
        }
        return true;
    }

    // Helper method to create an Event object from the input fields
    private Event createEventFromInputs() {
        if (event == null) {
            event = new Event(
                    patientName.getText().toString(),
                    doctorName.getText().toString(),
                    appointmentDate.getText().toString(),
                    appointmentStatus.getSelectedItem().toString(),
                    appointmentNotes.getText().toString(),
                    appointmentLocation.getText().toString()
            );
        } else {
            event.setPatientName(patientName.getText().toString());
            event.setDoctorName(doctorName.getText().toString());
            event.setAppointmentDate(appointmentDate.getText().toString());
            event.setStatus(appointmentStatus.getSelectedItem().toString());
            event.setNotes(appointmentNotes.getText().toString());
            event.setLocation(appointmentLocation.getText().toString());
        }
        return event;
    }

    // Helper method to set the Spinner selection based on a string value
    private void setSpinnerSelectionByValue(Spinner spinner, String value) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equals(value)) {
                spinner.setSelection(i);
                break;
            }
        }
    }
}
