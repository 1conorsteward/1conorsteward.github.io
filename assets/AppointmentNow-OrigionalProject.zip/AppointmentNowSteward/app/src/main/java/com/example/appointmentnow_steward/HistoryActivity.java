package com.example.appointmentnow_steward;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {

    private ArrayList<Event> completedEventsList;
    private DatabaseHelper databaseHelper;
    private EventAdapter eventAdapter;  // Class-level declaration

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Initialize close button and set click listener
        ImageButton closeButton = findViewById(R.id.close_button);
        closeButton.setOnClickListener(v -> finish());  // Close the activity when the close button is clicked

        // Initialize the UI components
        GridView completedEventsGrid = findViewById(R.id.completed_events_grid);
        EditText searchEditText = findViewById(R.id.search_edit_text);

        // Initialize the database helper
        databaseHelper = new DatabaseHelper(this);

        // Load completed events from the database
        loadCompletedEvents("");

        // Initialize and set up the event adapter for the GridView using the class-level variable
        eventAdapter = new EventAdapter(this, completedEventsList);
        completedEventsGrid.setAdapter(eventAdapter);

        // Search functionality
        searchEditText.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Reload the list based on search input
                loadCompletedEvents(s.toString());
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });
    }

    // Method to open edit dialog
    public void openEditEventDialog(Event event, int position) {
        AddEventDialogFragment dialog = AddEventDialogFragment.newInstance(event);
        dialog.setOnSaveListener(updatedEvent -> {
            // Update the event in the database
            boolean updated = databaseHelper.updateEvent(
                    event.getId(),
                    updatedEvent.getPatientName(),
                    updatedEvent.getDoctorName(),
                    updatedEvent.getAppointmentDate(),
                    updatedEvent.getStatus(),
                    updatedEvent.getNotes(),
                    updatedEvent.getLocation()
            );

            // Refresh the list if the event was updated
            if (updated) {
                completedEventsList.set(position, updatedEvent);
                eventAdapter.notifyDataSetChanged();  // Use class-level eventAdapter
                Toast.makeText(this, "Event updated successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error updating event.", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show(getSupportFragmentManager(), "EditEventDialog");
    }

    // Method to show delete confirmation dialog
    public void showDeleteConfirmationDialog(long eventId, int position) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Event")
                .setMessage("Are you sure you want to delete this event?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    // Delete the event from the database
                    boolean deleted = databaseHelper.deleteEvent(eventId);

                    // Remove the event from the list and refresh the adapter
                    if (deleted) {
                        completedEventsList.remove(position);
                        eventAdapter.notifyDataSetChanged();  // Use class-level eventAdapter
                        Toast.makeText(this, "Event deleted successfully!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Error deleting event.", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void loadCompletedEvents(String searchTerm) {
        if (completedEventsList == null) {
            completedEventsList = new ArrayList<>();
        }

        completedEventsList.clear();  // Clear the list to avoid duplicates

        // Retrieve the logged-in user ID from SharedPreferences
        SharedPreferences sharedPref = getSharedPreferences("AppPreferences", MODE_PRIVATE);
        long userId = sharedPref.getLong("user_id", -1);  // Default to -1 if not found

        if (userId != -1) {
            // Query completed events from the database
            Cursor cursor = databaseHelper.getCompletedEvents(userId, searchTerm);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    long id = cursor.getLong(cursor.getColumnIndexOrThrow("event_id"));
                    String patientName = cursor.getString(cursor.getColumnIndexOrThrow("patient_name"));
                    String doctorName = cursor.getString(cursor.getColumnIndexOrThrow("doctor_name"));
                    String appointmentDate = cursor.getString(cursor.getColumnIndexOrThrow("appointment_date"));
                    String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));
                    String notes = cursor.getString(cursor.getColumnIndexOrThrow("notes"));
                    String location = cursor.getString(cursor.getColumnIndexOrThrow("location"));

                    // Add the event to the list
                    completedEventsList.add(new Event(id, patientName, doctorName, appointmentDate, status, notes, location));
                }
                cursor.close();
            }
        } else {
            Toast.makeText(this, "Error loading history. Please log in again.", Toast.LENGTH_SHORT).show();
        }
    }
}
