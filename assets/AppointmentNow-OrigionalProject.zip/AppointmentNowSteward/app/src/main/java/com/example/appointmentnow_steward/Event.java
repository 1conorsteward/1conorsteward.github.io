package com.example.appointmentnow_steward;

import android.os.Parcel;
import android.os.Parcelable;

// The Event class represents an appointment event and implements the Parcelable interface
// to allow instances of this class to be passed between Android components.
public class Event implements Parcelable {

    // Fields representing the properties of an Event
    private long id;                  // Unique identifier for the event
    private String patientName;       // Name of the patient
    private String doctorName;        // Name of the doctor
    private String appointmentDate;   // Date of the appointment
    private String status;            // Status of the appointment (e.g., Scheduled, Completed)
    private String notes;             // Additional notes about the appointment
    private String location;          // Location of the appointment

    // Constructor to create an Event object with an ID (used for existing events in the database)
    public Event(long id, String patientName, String doctorName, String appointmentDate, String status, String notes, String location) {
        this.id = id;
        this.patientName = patientName;
        this.doctorName = doctorName;
        this.appointmentDate = appointmentDate;
        this.status = status;
        this.notes = notes;
        this.location = location;
    }

    // Constructor to create an Event object without an ID (used for new events)
    public Event(String patientName, String doctorName, String appointmentDate, String status, String notes, String location) {
        this.patientName = patientName;
        this.doctorName = doctorName;
        this.appointmentDate = appointmentDate;
        this.status = status;
        this.notes = notes;
        this.location = location;
    }

    // Constructor used by the Parcelable interface to create an Event object from a Parcel
    protected Event(Parcel in) {
        id = in.readLong();                        // Read the ID from the Parcel
        patientName = in.readString();             // Read the patient name from the Parcel
        doctorName = in.readString();              // Read the doctor name from the Parcel
        appointmentDate = in.readString();         // Read the appointment date from the Parcel
        status = in.readString();                  // Read the status from the Parcel
        notes = in.readString();                   // Read the notes from the Parcel
        location = in.readString();                // Read the location from the Parcel
    }

    // Method to write the Event object’s data to a Parcel (required by Parcelable)
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);                        // Write the ID to the Parcel
        dest.writeString(patientName);             // Write the patient name to the Parcel
        dest.writeString(doctorName);              // Write the doctor name to the Parcel
        dest.writeString(appointmentDate);         // Write the appointment date to the Parcel
        dest.writeString(status);                  // Write the status to the Parcel
        dest.writeString(notes);                   // Write the notes to the Parcel
        dest.writeString(location);                // Write the location to the Parcel
    }

    // Describe the contents of the Parcel (required by Parcelable)
    @Override
    public int describeContents() {
        return 0;
    }

    // Static field used to regenerate the object, individually or as arrays (required by Parcelable)
    public static final Creator<Event> CREATOR = new Creator<Event>() {
        // Method to create a new Event instance from a Parcel
        @Override
        public Event createFromParcel(Parcel in) {
            return new Event(in);
        }

        // Method to create a new array of Event instances
        @Override
        public Event[] newArray(int size) {
            return new Event[size];
        }
    };

    // Getters and Setters for the Event properties

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
